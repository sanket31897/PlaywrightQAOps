class DashBoardPage{

  constructor(page){
   this.page=page;
   this.products = page.locator(".card-body");
   this.productsText = page.locator(".card-body h5");
   this.cart= page.locator("[routerlink*='cart']");
}

async searchProduct(productName){
const allTitles= await this.productsText.allTextContents();
console.log(allTitles);
//console.log(await page.locator(".card-body h5").nth(0).textContent());

const count = await this.products.count();
for(let i=0; i<count; ++i){
   if(await this.products.nth(i).locator("b").textContent()===productName)
      {
      //add to cart
      await this.products.nth(i).locator("text= Add To Cart").click();
      break;

   }
}

}


async navigateToCart(){

    await this.cart.click();
}

}

module.exports= {DashBoardPage};